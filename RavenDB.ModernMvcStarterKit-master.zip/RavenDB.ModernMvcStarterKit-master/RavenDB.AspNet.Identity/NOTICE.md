# LICENSE NOTICES

RavenDB.AspNet.Identity  
ASP.NET Identity Provider for RaveNDB

Coypright 2013 [ILM Professional Services](http://www.ilmservices.com)  
Created by [David Boike](http://www.make-awesome.com)

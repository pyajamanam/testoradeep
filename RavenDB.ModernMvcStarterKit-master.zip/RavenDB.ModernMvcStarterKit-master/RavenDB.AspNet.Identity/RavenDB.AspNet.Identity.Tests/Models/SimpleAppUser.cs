﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RavenDB.AspNet.Identity;

namespace RavenDB.AspNet.Identity.Tests
{
    public class SimpleAppUser : IdentityUser
    {
    }
}
